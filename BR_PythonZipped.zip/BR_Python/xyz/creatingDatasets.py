import numpy as np
import csv
import sqlite3
import matplotlib.pyplot as plt
from scipy import stats
import mysql.connector as mySQL
import pandas as pd

clientID=str(516)

connect= mySQL.connect(
    host="localhost",
    user="root",
    password="Myname1sTeja!",
)
myCursor = connect.cursor()
myDataBase="Exp"+clientID

query = "CREATE DATABASE " + myDataBase
myCursor.execute(query)
connect.commit()

myConnection = mySQL.connect(
    host="localhost",
    user="root",
    password="Myname1sTeja!",
    database=myDataBase
)
myCursor=myConnection.cursor()

myTable="Exp_"+clientID
query='''CREATE TABLE {} (
                    ID int auto_increment primary key,
                    ResumeKey char(200),
                    ExpSeq char(200),
                    OrgName char(200),
                    StartYear char(200),
                    EndYear char(200),
                    JobTitle char(200)
                )
'''.format(myTable)
myCursor.execute(query)
myConnection.commit()

with open('D:\Downloads\Experience_516.csv', 'r') as csvfile:
    csvreader = csv.reader(csvfile)
    next(csvreader)  # Skip the header row

    for row in csvreader:
        query='''INSERT INTO {} (ResumeKey, ExpSeq, OrgName, StartYear, EndYear, JobTitle)
            VALUES (%s,%s,%s,%s,%s,%s)'''.format(myTable)
        myCursor.execute(query,(row[0],row[1],row[4],row[6],row[7],row[8]))
myConnection.commit()

query='''
    ALTER TABLE {} 
    MODIFY COLUMN ResumeKey INT;
    '''.format(myTable)
myCursor.execute(query)
myConnection.commit()

#* creating a tenure column
query = '''
    ALTER TABLE {} ADD COLUMN tenure int;
    '''.format(myTable)
myCursor.execute(query)
myConnection.commit()

#* setting the tenure value
query='''
    UPDATE {} SET Tenure = CONVERT(EndYear,SIGNED)-CONVERT(StartYear,SIGNED)
    WHERE (EndYear!='NULL' AND StartYear!='NULL');
    '''.format(myTable)
myCursor.execute(query)
myConnection.commit()

query='''
    ALTER TABLE {} DROP COLUMN StartYear;
    '''.format(myTable)
myCursor.execute(query)
myConnection.commit()
query='''
    ALTER TABLE {} DROP COLUMN EndYear;
    '''.format(myTable)
myCursor.execute(query)
myConnection.commit()

#* Collecting the applicants and their first job
query='''
    CREATE TABLE MaxValues_FreshersValues
    AS
    SELECT ResumeKey as `Key`,MAX(ExpSeq)
    FROM {} GROUP BY ResumeKey;
'''.format(myTable)
myCursor.execute(query)
myConnection.commit()

#* Creating the dataset1 combining the MaxValues_FreshersValues table and myTable
query='''
    CREATE TABLE DataSet1
    AS
    SELECT a.ResumeKey,a.ExpSeq AS ExpSeq1,a.OrgName AS OrgName1, a.jobTitle AS Role1,a.Tenure AS Tenure1
    FROM {} AS a
    RIGHT JOIN MaxValues_FreshersValues as b
    ON (a.ResumeKey=b.`Key` AND a.ExpSeq=b.`MAX(ExpSeq)`)
    ORDER BY ResumeKey    
    '''.format(myTable)
myCursor.execute(query)
myConnection.commit()

#* deleting rows where Tenure1 is null or <0 or >50
query = '''DELETE FROM DataSet1
    WHERE (Tenure1 IS NULL or Tenure1<0 or Tenure1>50)
'''
myCursor.execute(query)
myConnection.commit()
#*----------------------------- DATASET - 1 DONE -------------------------

#* Creating oneJobOnly by taking max value - 1, which contains the list of applicants and their 2nd jobs only (for now)
query='''
    CREATE TABLE oneJobOnly
    AS
    SELECT a.ResumeKey AS R2, a.ExpSeq as ExpSeq2,a.OrgName AS OrgName2,a.Tenure AS Tenure2,a.JobTitle AS Role2
    FROM {} AS a
    RIGHT JOIN MaxValues_FreshersValues AS t
    on (a.ResumeKey=t.`Key` and a.ExpSeq=t.`MAX(ExpSeq)`-1);
'''.format(myTable)
myCursor.execute(query)
myConnection.commit()

#* Deleting the null values
query='''
    DELETE FROM oneJobOnly
    WHERE Tenure2 IS null
'''
myCursor.execute(query)
myConnection.commit()

#* Creating the final Dataset2 by combining dataset1 and oneJobOnly
query='''
    CREATE TABLE DataSet2
    AS
    SELECT d2.R2, d1.OrgName1,d1.Role1, d1.Tenure1,d1.ExpSeq1,
    d2.Orgname2,d2.Role2,d2.Tenure2, d2.ExpSeq2
    FROM DataSet1 as d1
    RIGHT JOIN oneJobOnly as d2
    on (d2.R2=d1.ResumeKey)
    ORDER BY d2.R2;
'''
myCursor.execute(query)
myConnection.commit()
query='''
    ALTER TABLE Dataset2
    RENAME COLUMN R2 TO ResumeKey;
'''
myCursor.execute(query)
myConnection.commit()

#* deleting rows where Tenure2 is null or <0 or >50
query = '''DELETE FROM DataSet2
    WHERE (Tenure1 IS NULL or Tenure2 IS NULL or Tenure2<0 or Tenure2>50)
'''
myCursor.execute(query)
myConnection.commit()
#*-------------------------- DataSet - 2 DONE ------------------------

#* Creating twoJobsOnly by taking max value - 2, which contains the list of applicants and their 3rd jobs only (for now)
query='''
    CREATE TABLE twoJobsOnly
    AS
    SELECT a.ResumeKey AS R3, a.ExpSeq as ExpSeq3,a.OrgName AS OrgName3,a.Tenure AS Tenure3,a.JobTitle AS Role3
    FROM {} AS a
    RIGHT JOIN MaxValues_FreshersValues AS t
    on (a.ResumeKey=t.`Key` and a.ExpSeq=t.`MAX(ExpSeq)`-2);
'''.format(myTable)
myCursor.execute(query)
myConnection.commit()

#* Deleting the null values
query='''
    DELETE FROM twoJobsOnly
    WHERE Tenure3 IS null
'''
myCursor.execute(query)
myConnection.commit()

#* Creating the final Dataset3 by combining dataset2 and twoJobsOnly
query='''
    CREATE TABLE DataSet3
    AS
    SELECT d3.R3, d2.OrgName1,d2.Role1, d2.Tenure1,d2.ExpSeq1,
    d2.Orgname2,d2.Role2,d2.Tenure2, d2.ExpSeq2,
    d3.OrgName3,d3.Role3,d3.Tenure3,d3.ExpSeq3
    FROM DataSet2 as d2
    RIGHT JOIN twoJobsOnly as d3
    on (d3.R3=d2.ResumeKey)
    ORDER BY d3.R3
'''
myCursor.execute(query)
myConnection.commit()

query='''
    ALTER TABLE Dataset3
    RENAME COLUMN R3 TO ResumeKey;
'''
myCursor.execute(query)
myConnection.commit()

#* deleting rows where Tenure3 is null or <0 or >50
query = '''DELETE FROM DataSet3
    WHERE (Tenure1 IS NULL or Tenure2 IS NULL or Tenure3 IS NULL or Tenure3<0 or Tenure3>50)
'''
myCursor.execute(query)
myConnection.commit()
#*-------------------------- DataSet - 3 DONE --------------------------

#* Creating threeJobsOnly by taking max value - 3, which contains the list of applicants and their 4th jobs only (for now)
query='''
    CREATE TABLE threeJobsOnly
    AS
    SELECT a.ResumeKey AS R4, a.ExpSeq as ExpSeq4,a.OrgName AS OrgName4,a.Tenure AS Tenure4,a.JobTitle AS Role4
    FROM {} AS a
    RIGHT JOIN MaxValues_FreshersValues AS t
    on (a.ResumeKey=t.`Key` and a.ExpSeq=t.`MAX(ExpSeq)`-3);
'''.format(myTable)
myCursor.execute(query)
myConnection.commit()

#* Deleting the null values
query='''
    DELETE FROM threeJobsOnly
    WHERE Tenure4 IS null
'''
myCursor.execute(query)
myConnection.commit()

#* Creating the final Dataset4 by combining dataset3 and threeJobsOnly
query='''
    CREATE TABLE DataSet4
    AS
    SELECT d4.R4, d3.OrgName1,d3.Role1, d3.Tenure1,d3.ExpSeq1,
    d3.Orgname2,d3.Role2,d3.Tenure2, d3.ExpSeq2,
    d3.OrgName3,d3.Role3,d3.Tenure3,d3.ExpSeq3,
    d4.OrgName4,d4.Role4,d4.Tenure4,d4.ExpSeq4
    FROM DataSet3 as d3
    RIGHT JOIN threeJobsOnly as d4
    on (d4.R4=d3.ResumeKey)
    ORDER BY d4.R4
'''
myCursor.execute(query)
myConnection.commit()

query='''
    ALTER TABLE Dataset4
    RENAME COLUMN R4 TO ResumeKey;
'''
myCursor.execute(query)
myConnection.commit()

#* deleting rows where Tenure4 is null or <0 or >50
query = '''DELETE FROM DataSet4
    WHERE (Tenure1 IS NULL or Tenure2 IS NULL or Tenure3 IS NULL or Tenure4 IS NULL or Tenure4<0 or Tenure4>50)
'''
myCursor.execute(query)
myConnection.commit()
#*-------------------------- DataSet - 4 DONE --------------------------

#* Creating fourJobsOnly by taking max value - 4, which contains the list of applicants and their 5th jobs only (for now)
query='''
    CREATE TABLE fourJobsOnly
    AS
    SELECT a.ResumeKey AS R5, a.ExpSeq as ExpSeq5,a.OrgName AS OrgName5,a.Tenure AS Tenure5,a.JobTitle AS Role5
    FROM {} AS a
    RIGHT JOIN MaxValues_FreshersValues AS t
    on (a.ResumeKey=t.`Key` and a.ExpSeq=t.`MAX(ExpSeq)`-4);
'''.format(myTable)
myCursor.execute(query)
myConnection.commit()

#* Deleting the null values
query='''
    DELETE FROM fourJobsOnly
    WHERE Tenure5 IS null
'''
myCursor.execute(query)
myConnection.commit()

#* Creating the final Dataset5 by combining dataset4 and fourJobsOnly
query='''
    CREATE TABLE DataSet5
    AS
    SELECT d5.R5, d4.OrgName1,d4.Role1, d4.Tenure1,d4.ExpSeq1,
    d4.Orgname2,d4.Role2,d4.Tenure2, d4.ExpSeq2,
    d4.OrgName3,d4.Role3,d4.Tenure3,d4.ExpSeq3,
    d4.OrgName4,d4.Role4,d4.Tenure4,d4.ExpSeq4,
    d5.OrgName5,d5.Role5,d5.Tenure5,d5.ExpSeq5
    FROM DataSet4 as d4
    RIGHT JOIN fourJobsOnly as d5
    on (d5.R5=d4.ResumeKey)
    ORDER BY d5.R5
'''
myCursor.execute(query)
myConnection.commit()

query='''
    ALTER TABLE Dataset5
    RENAME COLUMN R5 TO ResumeKey;
'''
myCursor.execute(query)
myConnection.commit()

#* deleting rows where Tenure4 is null or <0 or >50
query = '''DELETE FROM DataSet5
    WHERE (Tenure1 IS NULL or Tenure2 IS NULL or Tenure3 IS NULL or Tenure4 IS NULL or Tenure5 IS NULL or Tenure5<0 or Tenure5>50)
'''
myCursor.execute(query)
myConnection.commit()

#*-------------------------- DataSet - 5 DONE ----------------------------
sql_query = pd.read_sql_query ('''
                               SELECT
                               *
                               FROM Dataset1
                               ''', myConnection)

DataFrame1 = pd.DataFrame(sql_query, columns = ['ResumeKey','OrgName1', 'Role1', 'Tenure1'])

OrgName_1=np.array([])
Role_1=np.array([])
Tenure_1=np.array([])
for value in DataFrame1.iterrows():
    dictionary=dict(value[1])
    np.append(OrgName_1,dictionary["OrgName1"])
    np.append(Role_1,dictionary["Role1"])
    np.append(Tenure_1,dictionary["Tenure1"])

plt.scatter(OrgName_1, Tenure_1)
plt.show()
myCursor.close()
myConnection.close()